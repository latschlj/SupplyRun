package com.brackeen.javagamebook.tilegame.sprites;

import com.brackeen.javagamebook.graphics.Animation;
import com.brackeen.javagamebook.graphics.Sprite;

public class Bullet extends Sprite{

	 
	private float xVelocity = (float) 0.3;
	public static final float SQRTRANGE = 1000*500;
	private float stX,stY;
	
	
	public Bullet(Animation anim) {
		super(anim);
		this.dx = xVelocity;
		this.dy = 0;
		// TODO Auto-generated constructor stub
	}
	
	public Object clone() {
        return new Bullet(anim);
    }

	public void shoot(float x, float y) {
		stX = x;
		setX(x);
		stY = y;
		setY(y);
	}

	public double getSqrtTraveledDistance() {
		float dX =  Math.abs(stX-this.getX());
		float dY = Math.abs(stY-this.getY());
		return (dX*dX+dY*dY);
		
	}

	public void setDirection(int direction) {
		this.dx *=direction;
	}
	
	

	
	
	
	
}
