package com.brackeen.javagamebook.tilegame.sprites;

import java.lang.reflect.Constructor;
import com.brackeen.javagamebook.graphics.*;
import com.brackeen.javagamebook.graphics.Animation.AnimFrame;
import com.brackeen.javagamebook.tilegame.TileMap;

/**
    A PowerUp class is a Sprite that the player can pick up.
*/
public abstract class PowerUp extends Sprite {

    public PowerUp(Animation anim) {
        super(anim);
    }


    public Object clone() {
        // use reflection to create the correct subclass
        Constructor constructor = getClass().getConstructors()[0];
        try {
            return constructor.newInstance(
                new Object[] {(Animation)anim.clone()});
        }
        catch (Exception ex) {
            // should never happen
            ex.printStackTrace();
            return null;
        }
    }


    /**
        A Star PowerUp. Gives the player points.
    */
    public static class Star extends PowerUp {
        public Star(Animation anim) {
            super(anim);
        }
    }


    /**
        A Music PowerUp. Changes the game music.
    */
    public static class Music extends PowerUp {
    	private boolean active;
		private boolean moving;
		private long timeMoving;
		private TileMap map;
        public Music(Animation anim) {
            super(anim);
        }
        
        
        public void update(long elapsedTime) {
        	new Thread() {
        	    public void run() {
        	        if(moving){
        	        	 timeMoving = timeMoving + elapsedTime;
                   	 	 x += dx * elapsedTime;
        	             y += dy * elapsedTime;
        	             anim.update(elapsedTime);
        	             if(timeMoving>anim.getTotalDuration()){
        	            	  anim.reserseFrames();
        	            	 
        	            	 moving =  false;
        	            	 timeMoving = 0;
        	            	 map.setFaded(!map.getFaded());
        	             }
        	        }
        	    }
        	}.start();
        	
              	
        }
        
        
        public void trigger(TileMap map){
        	active=!active;
        	if(!moving){
        		moving=true;
        	}
        	this.map = map;
        	/*if(!moving && !acquired){
        		moving=true;
        		acquired = true;
        	}*/
        	
        	
        }


		
        
    }


    /**
        A Goal PowerUp. Advances to the next map.
    */
    public static class Goal extends PowerUp {
        public Goal(Animation anim) {
            super(anim);
        }
    }

}
