package com.brackeen.javagamebook.tilegame.sprites;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import java.awt.Color;
import javax.swing.SwingConstants;

public class gh {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					gh window = new gh();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public gh() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 501);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblHoldLeftArrow = new JLabel("Hold left arrow key to end cutscene.");
		lblHoldLeftArrow.setHorizontalAlignment(SwingConstants.CENTER);
		lblHoldLeftArrow.setForeground(new Color(192, 192, 192));
		lblHoldLeftArrow.setBackground(new Color(128, 0, 0));
		lblHoldLeftArrow.setBounds(0, 330, 434, 60);
		frame.getContentPane().add(lblHoldLeftArrow);
	}

}
