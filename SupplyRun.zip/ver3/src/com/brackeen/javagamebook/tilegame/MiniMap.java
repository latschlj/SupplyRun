package com.brackeen.javagamebook.tilegame;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Image;

import javax.management.timer.TimerMBean;

import com.brackeen.javagamebook.graphics.Sprite;
import com.brackeen.javagamebook.tilegame.sprites.Player;

public class MiniMap {
	
	
	private TileMap map;



	public MiniMap(TileMap tileMap) {
		this.map = tileMap;
	
	
	
	
	/*int firstTileX = pixelsToTiles(-offsetX);
    int lastTileX = firstTileX +
        pixelsToTiles(screenWidth) + 1;*/
   
	}
	

	int size = 5;
	public void draw(Graphics2D g, Sprite player){
		g.setColor(Color.white);
		 for (int y=0; y<map.getHeight(); y++) {
		        for (int x=0; x <= map.getWidth(); x++) {
		            Image image = map.getTile(x, y);
		            if (image != null) {
		            	g.drawRect(1+x*size, 1+y*size, size, size);
		            }
		        }
		    }
		 int pX = TileMapRenderer.pixelsToTiles(player.getX()); 
		 int pY = TileMapRenderer.pixelsToTiles(player.getY());
		  
		 g.setColor(Color.green);
	     g.fillRect(1+pX*size,1+pY*size, size, size);
	}



}
