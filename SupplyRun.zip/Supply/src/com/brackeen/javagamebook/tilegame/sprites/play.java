package com.brackeen.javagamebook.tilegame.sprites;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class play extends JFrame {

    public static int difficulty=-1;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					play frame = new play();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public play() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 543, 546);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(128, 0, 0));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnEasy = new JButton("Easy");
		btnEasy.setForeground(Color.WHITE);
		btnEasy.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnEasy.setBackground(new Color(0, 0, 0));
		btnEasy.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				difficulty=0;
				dispose();
			}
		});
		btnEasy.setBounds(10, 201, 208, 65);
		contentPane.add(btnEasy);
		
		JButton btnNewButton = new JButton("Normal");
		btnNewButton.setForeground(Color.WHITE);
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnNewButton.setBackground(new Color(0, 0, 0));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				difficulty=1;
				dispose();
			}
		});
		btnNewButton.setBounds(311, 201, 206, 65);
		
		contentPane.add(btnNewButton);
		
		JLabel lblSelectDifficulty = new JLabel("Select Difficulty");
		lblSelectDifficulty.setForeground(new Color(192, 192, 192));
		lblSelectDifficulty.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblSelectDifficulty.setHorizontalAlignment(SwingConstants.CENTER);
		lblSelectDifficulty.setBounds(175, 88, 198, 40);
		contentPane.add(lblSelectDifficulty);
	}
}
