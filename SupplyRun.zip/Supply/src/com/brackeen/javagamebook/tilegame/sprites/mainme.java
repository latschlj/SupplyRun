package com.brackeen.javagamebook.tilegame.sprites;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import com.brackeen.javagamebook.tilegame.GameManager;

public class mainme extends JFrame {

    public static int difficulty=-1;

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					mainme frame = new mainme();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public static int check() {
		
		return difficulty;
	}
	/**
	 * Create the frame.
	 */
	public mainme() {
			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			setBounds(100, 100, 543, 546);
			contentPane = new JPanel();
			contentPane.setBackground(new Color(128, 0, 0));
			contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
			setContentPane(contentPane);
			contentPane.setLayout(null);
			
			JLabel lblNewLabel = new JLabel("");
			lblNewLabel.setBounds(119, 30, 285, 266);
			lblNewLabel.setIcon(new ImageIcon("C:\\Users\\laptop\\workspace\\jsfd\\images\\slog.png"));
			contentPane.add(lblNewLabel);
			
			JButton btnHowToPlay = new JButton("Controls");
			btnHowToPlay.setFont(new Font("Tahoma", Font.PLAIN, 30));
			btnHowToPlay.setBounds(377, 422, 150, 86);
			btnHowToPlay.setHorizontalAlignment(SwingConstants.LEFT);
			btnHowToPlay.setBackground(new Color(0, 0, 0));
			btnHowToPlay.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					try {
						controls frame = new controls();
						frame.setVisible(true);
					} catch (Exception po) {
						po.printStackTrace();
					}
				}
			});
			
			JButton btnPlay = new JButton("\r\n\t\t\tPlay\t\t\t\r\n");
			btnPlay.setFont(new Font("Tahoma", Font.PLAIN, 33));
			btnPlay.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					try {
						play frame = new play();
						frame.setVisible(true);
					} catch (Exception e) {
						e.printStackTrace();
					}
					difficulty=play.difficulty;
					
				}
			});
			btnPlay.setBounds(189, 422, 189, 86);
			btnPlay.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseClicked(MouseEvent arg0) {
				}
			});
			lblNewLabel.setIcon(new ImageIcon("C:\\Users\\laptop\\Desktop\\slog.png"));
			btnPlay.setBackground(new Color(0, 0, 0));
			contentPane.add(btnPlay);
			
			JButton btnHighScores = new JButton("High Scores");
			btnHighScores.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					try {
						scores frame = new scores();
						frame.setVisible(true);
					} catch (Exception ee) {
						ee.printStackTrace();
					}
				}
			});
			btnHighScores.setFont(new Font("Tahoma", Font.PLAIN, 28));
			btnHighScores.setBounds(0, 422, 189, 86);
			btnHighScores.setHorizontalAlignment(SwingConstants.RIGHT);
			btnHighScores.setBackground(new Color(0, 0, 0));
			contentPane.add(btnHighScores);
			contentPane.add(btnHowToPlay);
			
			JLabel lblNewLabel_1 = new JLabel("Can you Escape?");
			lblNewLabel_1.setForeground(new Color(192, 192, 192));
			lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 22));
			lblNewLabel_1.setIcon(new ImageIcon("C:\\Users\\laptop\\workspace\\jsfd\\images\\player2.png"));
			lblNewLabel_1.setBounds(255, 292, 262, 93);
			contentPane.add(lblNewLabel_1);
			
			JLabel label = new JLabel("");
			label.setIcon(new ImageIcon("C:\\Users\\laptop\\workspace\\jsfd\\images\\heart2.png"));
			label.setBounds(23, 299, 80, 86);
			contentPane.add(label);
		}
	}
