package com.brackeen.javagamebook.tilegame.sprites;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.Color;

public class controls extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					controls frame = new controls();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public controls() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 543, 546);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(128, 0, 0));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Press the A/D keys move your character Left/Right");
		lblNewLabel.setForeground(new Color(192, 192, 192));
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(5, 5, 512, 34);
		contentPane.add(lblNewLabel);
		
		JLabel lblWMakesYour = new JLabel("Press W to Jump");
		lblWMakesYour.setForeground(new Color(192, 192, 192));
		lblWMakesYour.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblWMakesYour.setHorizontalAlignment(SwingConstants.CENTER);
		lblWMakesYour.setBounds(5, 50, 512, 34);
		contentPane.add(lblWMakesYour);
		
		JLabel lblEnterAllowsYour = new JLabel("Press enter to interact with Levers");
		lblEnterAllowsYour.setForeground(new Color(192, 192, 192));
		lblEnterAllowsYour.setHorizontalAlignment(SwingConstants.CENTER);
		lblEnterAllowsYour.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblEnterAllowsYour.setBounds(5, 95, 512, 34);
		contentPane.add(lblEnterAllowsYour);
		
		JLabel lblSpaceWillMake = new JLabel("Press space to Shoot your gun");
		lblSpaceWillMake.setForeground(new Color(192, 192, 192));
		lblSpaceWillMake.setHorizontalAlignment(SwingConstants.CENTER);
		lblSpaceWillMake.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblSpaceWillMake.setBounds(5, 140, 512, 43);
		contentPane.add(lblSpaceWillMake);
		
		JLabel lblMWillMake = new JLabel ("Press the m button, To toggle mute");
		lblMWillMake.setForeground(new Color (192, 192, 192));
		lblMWillMake.setHorizontalAlignment(SwingConstants.CENTER);
		lblMWillMake.setFont(new Font("tahoma", Font.PLAIN, 16));
		lblMWillMake.setBounds(5, 190, 512,34);
		contentPane.add(lblMWillMake);
	}

}
