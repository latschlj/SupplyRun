package com.brackeen.javagamebook.tilegame.sprites;

import java.util.ArrayList;

import com.brackeen.javagamebook.graphics.Animation;
import com.brackeen.javagamebook.graphics.Sprite;
import com.brackeen.javagamebook.tilegame.TileMap;

/**
    The Player.
*/
public class Player extends Creature {

    private static final float JUMP_SPEED = -.95f;

    private boolean onGround;
    private ArrayList<Bullet> bullets;

	private int direction;
    
    
    public Player(Animation left, Animation right,
        Animation deadLeft, Animation deadRight)
    {
        super(left, right, deadLeft, deadRight);
        bullets = new ArrayList<Bullet>();
        this.direction = 1;
    }


    public void collideHorizontal() {
        setVelocityX(0);
    }


    public void collideVertical() {
        // check if collided with ground
        if (getVelocityY() > 0) {
            onGround = true;
        }
        setVelocityY(0);
    }


    public void setY(float y) {
        // check if falling
        if (Math.round(y) > Math.round(getY())) {
            onGround = false;
        }
        super.setY(y);
    }


    public void wakeUp() {
        // do nothing
    }


    /**
        Makes the player jump if the player is on the ground or
        if forceJump is true.
    */
    public void jump(boolean forceJump) {
        //if (onGround || forceJump) {
            onGround = false;
            setVelocityY(JUMP_SPEED);
        //}
    	
    }


    public float getMaxSpeed() {
        return 0.5f;
    }


	public void shoot(TileMap map) {
		if(bullets.size()>0){
			Bullet b = bullets.remove(0);
			b.setDirection(this.direction);
			b.shoot(this.x, this.y);
			map.addSprite(b);
			System.out.println("Bullets: "+bullets.size());
		}
		
	}


	public void pickUpBullet(ArrayList<Bullet> availableBullets) {
		
		bullets.add(availableBullets.remove(0));
		
		
		
	}


	/** 1 for right, and -1 for left*/
	public void setDirection(int direction) {
		this.direction =  direction;
		
	}
	
	
	

}


