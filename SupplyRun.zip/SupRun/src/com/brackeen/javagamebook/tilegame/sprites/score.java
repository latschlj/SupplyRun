package com.brackeen.javagamebook.tilegame.sprites;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Color;
import javax.swing.JTextArea;

public class score extends JFrame {

	private JPanel contentPane;
	private JTextArea textArea_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					score frame = new score();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public score() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 543, 546);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(128, 0, 0));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		JLabel lblNameHighScore = new JLabel("Name  High Score");
		lblNameHighScore.setForeground(new Color(192, 192, 192));
		contentPane.add(lblNameHighScore, BorderLayout.NORTH);
		
		JTextArea textArea = new JTextArea();
		textArea.setBackground(new Color(128, 0, 0));
		//
		Scanner scan = new Scanner(System.in);
		int maxLine = 10;
		int fail = 0;
		String name = "";
		String n = "";
		try {
			FileReader f = new FileReader("scores.txt");
			BufferedReader in = new BufferedReader(f);

			for (int i = 0; i < maxLine; i++){
				n = in.readLine();
				name += n + "\n";
			}

		}catch (IOException e) {
			fail = 1;
		}
		if (fail == 0){
			textArea = new JTextArea();
			textArea.setBounds(12,13,501,407);
			
		}else{
			textArea = new JTextArea("NO HIGHSCORES FOUND");
			textArea.setForeground(new Color (192,192,192));
		}
		
		
		
		textArea_1 = new JTextArea(name);
		textArea_1.setForeground(new Color(192, 192, 192));
		textArea_1.setBackground(new Color(128, 0, 0));
		textArea_1.setBounds(12, 13, 501, 473);
		contentPane.add(textArea_1, BorderLayout.CENTER);
		
		
	}

}
