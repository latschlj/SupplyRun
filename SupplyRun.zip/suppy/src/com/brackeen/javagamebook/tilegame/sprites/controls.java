package com.brackeen.javagamebook.tilegame.sprites;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.Color;

public class controls extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					controls frame = new controls();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public controls() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 543, 546);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(128, 0, 0));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("A/D moves your character Left/Right");
		lblNewLabel.setForeground(new Color(192, 192, 192));
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(5, 5, 512, 34);
		contentPane.add(lblNewLabel);
		
		JLabel lblWMakesYour = new JLabel("W makes your character Jump");
		lblWMakesYour.setForeground(new Color(192, 192, 192));
		lblWMakesYour.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblWMakesYour.setHorizontalAlignment(SwingConstants.CENTER);
		lblWMakesYour.setBounds(5, 50, 512, 34);
		contentPane.add(lblWMakesYour);
		
		JLabel lblEnterAllowsYour = new JLabel("Enter allows your character to interact with Levers");
		lblEnterAllowsYour.setForeground(new Color(192, 192, 192));
		lblEnterAllowsYour.setHorizontalAlignment(SwingConstants.CENTER);
		lblEnterAllowsYour.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblEnterAllowsYour.setBounds(5, 95, 512, 34);
		contentPane.add(lblEnterAllowsYour);
		
		JLabel lblSpaceWillMake = new JLabel("Space will make you Shoot");
		lblSpaceWillMake.setForeground(new Color(192, 192, 192));
		lblSpaceWillMake.setHorizontalAlignment(SwingConstants.CENTER);
		lblSpaceWillMake.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblSpaceWillMake.setBounds(5, 140, 512, 43);
		contentPane.add(lblSpaceWillMake);
	}

}
