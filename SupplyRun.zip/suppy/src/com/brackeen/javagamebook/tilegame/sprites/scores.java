package com.brackeen.javagamebook.tilegame.sprites;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Color;

public class scores extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					scores frame = new scores();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public scores() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 543, 546);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(128, 0, 0));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		int fail = 0;
		String name="";
		JLabel lblNewLabel;
		try {
			FileReader f = new FileReader("scores.txt");
			BufferedReader in = new BufferedReader(f);
			name=in.readLine();
		} catch (IOException e) {
			fail = 1;
		}
		if (fail == 0) {
			
			lblNewLabel = new JLabel(name);

			lblNewLabel.setForeground(new Color(192, 192, 192));
		}
		else{
			lblNewLabel = new JLabel("No High scores found.");
			lblNewLabel.setForeground(new Color(192, 192, 192));
		}
		contentPane.add(lblNewLabel, BorderLayout.CENTER);
		
		JLabel lblNameHighScore = new JLabel("Name  High Score");
		lblNameHighScore.setForeground(new Color(192, 192, 192));
		contentPane.add(lblNameHighScore, BorderLayout.NORTH);
	}

}
